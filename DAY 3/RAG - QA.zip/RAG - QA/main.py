import streamlit as st
from rag_utils import parse_pdf, embed_chunks, build_faiss_index, retrieve_similar_chunks, generate_answer
import tempfile
import os
import base64

# --- PAGE CONFIG ---
st.set_page_config(
    page_title="Gemini RAG Q&A",
    page_icon="🤖",
    layout="wide",
    initial_sidebar_state="collapsed"
)

# --- CUSTOM STYLES ---
st.markdown("""
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background-color: #f8fafc;
            margin: 0;
        }

        .main-title {
            font-size: 2.2rem;
            font-weight: 700;
            text-align: center;
            background-image: linear-gradient(90deg, rgb(255, 75, 75), rgb(255, 253, 128));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .instructions {
            font-size: 0.95rem;
            color: #6b7280;
            text-align: center;
            margin-bottom: 2rem;
        }

        .answer-box {
            position: relative;
            background-color: #1f2937;
            color: white;
            padding: 1.5rem;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            margin-top: 1rem;
        }

        .action-icons {
            position: absolute;
            top: 10px;
            right: 15px;
        }

        .action-icons a, .action-icons button {
            background: none;
            border: none;
            font-size: 1.2rem;
            color: white;
            margin-left: 10px;
            cursor: pointer;
        }

        .action-icons button:focus {
            outline: none;
        }

        .question, .answer {
            margin-top: 1rem;
            font-size: 1rem;
            line-height: 1.6;
        }

        @media (max-width: 768px) {
            .main-title {
                font-size: 1.8rem;
            }
            .instructions {
                font-size: 0.85rem;
            }
        }
    </style>
""", unsafe_allow_html=True)

# --- HEADER ---
st.markdown("<div class='main-title'>Ask Question Get Answer</div>", unsafe_allow_html=True)
st.markdown(
    "<div class='instructions'>Upload one or more PDFs, ask a question, and get precise answers based on the content.</div>",
    unsafe_allow_html=True
)

# --- SESSION STATE FOR CACHED CHUNKS ---
if "cached_chunks" not in st.session_state:
    st.session_state.cached_chunks = []

# --- INPUT SECTION ---
uploaded_files = st.file_uploader("🗂 Upload PDF(s)", type=["pdf"], accept_multiple_files=True)
question = st.text_input("❓ Ask a question about the PDF(s)")
submit_button = st.button("Submit", key="submit", type="primary")

# --- Process Files on Upload ---
if uploaded_files:
    new_chunks = []
    for file in uploaded_files:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".pdf") as tmp:
            tmp.write(file.read())
            tmp_path = tmp.name
        chunks = parse_pdf(tmp_path)
        new_chunks.extend(chunks)
        os.unlink(tmp_path)
    st.session_state.cached_chunks = new_chunks

# --- OUTPUT SECTION ---

if submit_button:
    if not st.session_state.cached_chunks or not question:
        st.error("⚠️ Please upload at least one PDF and enter a question.")
    else:
        all_chunks = st.session_state.cached_chunks

        with st.spinner("🔍 Analyzing PDFs and generating answer..."):
            embeddings = embed_chunks(all_chunks)
            index = build_faiss_index(embeddings)
            top_chunks = retrieve_similar_chunks(index, embeddings, all_chunks, question)
            answer = generate_answer(top_chunks, question)

        # --- Display Answer Box ---
        st.markdown(f"""
        <div class='answer-box'>
            <div class='action-icons'>
                <a href='data:text/plain;base64,{base64.b64encode(answer.encode()).decode()}' download='answer.txt' title='Download'>📥</a>
            </div>
            <div class='question'><b>Question:</b><br>{question}</div>
            <div class='answer'><b>Answer:</b><br>{answer}</div>
        </div>
        """, unsafe_allow_html=True)

elif uploaded_files or st.session_state.cached_chunks:
    st.info("✅ PDFs uploaded. Now ask a question to get an answer.")
else:
    st.info("Upload a PDF and ask a question to see the answer here.")

