import fitz  # PyMuPDF
import faiss
import numpy as np
import google.generativeai as genai
from dotenv import load_dotenv
import os

load_dotenv()
genai.configure(api_key=os.getenv("GEMINI_API_KEY"))

# Initialize embedding model
embed_model = genai.embed_content

def parse_pdfs(file_paths):
    all_chunks = []
    for path in file_paths:
        all_chunks.extend(parse_pdf(path))  # ✅ Now this calls the real parse_pdf() for each file
    return all_chunks

def parse_pdf(file_path):
    doc = fitz.open(file_path)
    chunks = []
    for page in doc:
        chunks.append(page.get_text())
    return chunks



def embed_chunks(chunks):
    embeddings = [np.array(embed_model(model="models/embedding-001", content=chunk, task_type="retrieval_document")["embedding"]) for chunk in chunks]
    return np.array(embeddings, dtype='float32')

def build_faiss_index(embeddings):
    dim = embeddings.shape[1]
    index = faiss.IndexFlatL2(dim)
    index.add(embeddings)
    return index

def retrieve_similar_chunks(index, embeddings, chunks, question, k=3):
    question_embedding = np.array(embed_model(model="models/embedding-001", content=question, task_type="retrieval_query")["embedding"]).astype('float32').reshape(1, -1)
    distances, indices = index.search(question_embedding, k)
    return [chunks[i] for i in indices[0]]

def generate_answer(context_chunks, question):

    formatted_context = "\n\n".join(context_chunks)
    
    prompt = f"""You are a helpful assistant. Answer the question based only on the following context:\n\n{formatted_context}\n\nQuestion: {question}"""
    
    model = genai.GenerativeModel("gemini-1.5-flash")
    try:
        response = model.generate_content(prompt)
        return response.text
    except Exception as e:
        return f"⚠️ Gemini API error: {str(e)}"



