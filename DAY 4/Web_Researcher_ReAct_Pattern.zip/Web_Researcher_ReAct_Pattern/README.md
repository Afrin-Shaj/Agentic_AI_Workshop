Research Report on ReAct Agent: 

i. How LLM is Used for Reasoning

The LLM (gemini-1.5-flash) helps the ReAct agent think by generating 5-6 research questions for a topic via a prompt. It reasons by understanding the topic and creating relevant questions, which are then cleaned and used. The "Thought" step logs this process, followed by an "Observation" to check the output.

ii. Code and Flow Explanation

Code: A Streamlit app with a ResearchAgent class using LLM and Tavily for web searches. It logs steps (Thought, Action, Observation) and saves a report.

Flow: User enters a topic, clicks to generate questions, then a report. The agent thinks (generates questions), acts (searches web), and observes (logs results), showing live updates in the sidebar.

