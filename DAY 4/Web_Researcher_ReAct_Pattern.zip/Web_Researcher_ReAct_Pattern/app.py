import os
import streamlit as st
from dotenv import load_dotenv
import google.generativeai as genai
from tavily import TavilyClient
from datetime import datetime

class ResearchAgent:
    def __init__(self, topic):
        load_dotenv()
        self.topic = topic
        self.gemini_api_key = os.getenv("GEMINI_API_KEY")
        self.tavily_api_key = os.getenv("TAVILY_API_KEY")

        genai.configure(api_key=self.gemini_api_key)
        self.model = genai.GenerativeModel('gemini-1.5-flash')
        self.tavily = TavilyClient(api_key=self.tavily_api_key)

        self.questions = []
        self.research_data = {}
        self.react_log = []

    def log_react_step(self, step_type, content):
        timestamp = datetime.now().strftime("%H:%M:%S")
        short_type = step_type[0]  # T, A, or O
        short_content = content[:70] + ("..." if len(content) > 70 else "")
        formatted_log = f"<b>[{timestamp}]</b> <code>{short_type}</code>: {short_content}"
        self.react_log.append(formatted_log + "<br><br>")
        # Update the log display in real-time
        if 'log_box' in st.session_state:
            st.session_state.log_box.markdown(
                """<div style='font-size: 0.85rem;'>""" + "".join(self.react_log) + """</div>""",
                unsafe_allow_html=True
            )

    def generate_research_questions(self):
        self.log_react_step("Thought", f"Generating questions for '{self.topic}'")
        prompt = f"""
        Given the topic "{self.topic}", generate 5-6 well-structured research questions 
        that cover different aspects of the topic. Return the questions as a bullet point list.
        """
        response = self.model.generate_content(prompt)
        # Improved cleaning logic to remove bullet points, numbers, and special characters
        self.questions = [
            q.strip('-•* \t"0123456789.') for q in response.text.split('\n') 
            if q.strip() and len(q.strip()) > 3
        ]
        self.log_react_step("Observation", f"{len(self.questions)} questions generated.")
        return self.questions

    def search_web(self, question):
        self.log_react_step("Thought", f"Searching: {question}")
        self.log_react_step("Action", f"Querying Tavily: {question}")
        try:
            search_results = self.tavily.search(query=question, max_results=3)
            results = []
            for result in search_results['results']:
                results.append({
                    'title': result['title'],
                    'content': result.get('content', '')
                })
            self.log_react_step("Observation", f"{len(results)} results found.")
            return results
        except Exception as e:
            self.log_react_step("Observation", f"Search error: {str(e)}")
            return [{'title': 'Error', 'content': f'Failed to fetch results: {str(e)}'}]

    def collect_research_data(self):
        for question in self.questions:
            self.research_data[question] = self.search_web(question)
            self.log_react_step("Thought", f"Summarized: {question}")

    def generate_report(self):
        self.log_react_step("Thought", "Compiling report")
        report = f"""
<h1>📘 Research Report: {self.topic}</h1>
<h2>Introduction</h2>
<p>This report explores the topic <strong>{self.topic}</strong> by addressing critical questions and leveraging web search results.</p>
"""
        for idx, question in enumerate(self.questions, 1):
            report += f"<h3>{idx}. {question}</h3>\n<ul>"
            results = self.research_data.get(question, [])
            if results:
                for result in results:
                    report += f"<li><strong>{result['title']}</strong><br>{result['content']}</li>"
            else:
                report += "<li>No results found.</li>"
            report += "</ul>"

        filename = f"research_report_{self.topic.lower().replace(' ', '_')}.md"
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(report)
        self.log_react_step("Action", f"Saved report: {filename}")
        return report, filename

def main():
    st.set_page_config(layout="wide")
    st.title("🌐 Web Research Agent (ReAct Pattern)")

    # Initialize the log box in session state
    with st.sidebar:
        st.header("🪵 ReAct Logs")
        st.session_state.log_box = st.empty()

    topic = st.text_input("Enter research topic:")

    if 'questions' not in st.session_state:
        st.session_state.questions = []
    if 'report' not in st.session_state:
        st.session_state.report = None
    if 'react_log' not in st.session_state:
        st.session_state.react_log = []
    if 'report_filename' not in st.session_state:
        st.session_state.report_filename = None

    if st.button("🧠 Generate Research Questions"):
        with st.spinner("Generating questions..."):
            agent = ResearchAgent(topic)
            st.session_state.questions = agent.generate_research_questions()
            st.session_state.react_log = agent.react_log
        st.subheader("📌 Questions")
        for idx, q in enumerate(st.session_state.questions, 1):
            st.markdown(f"{idx}. {q}")

    if st.session_state.questions and st.button("📄 Generate Report"):
        with st.spinner("Researching and compiling report..."):
            agent = ResearchAgent(topic)
            agent.questions = st.session_state.questions
            agent.react_log = st.session_state.react_log
            agent.collect_research_data()
            report, filename = agent.generate_report()
            st.session_state.report = report
            st.session_state.report_filename = filename
            st.session_state.react_log = agent.react_log

        st.subheader("📘 Research Report")
        with st.container():
            st.markdown(
                f"""
                <div style='border: 1px solid #ccc; padding: 1.5rem; border-radius: 8px; font-size: 1.1rem; width: 100%;'>
                {st.session_state.report}
                </div>
                """,
                unsafe_allow_html=True
            )
        st.download_button(
            label="📥 Download Report",
            data=st.session_state.report,
            file_name=st.session_state.report_filename,
            mime="text/markdown"
        )

if __name__ == "__main__":
    main()