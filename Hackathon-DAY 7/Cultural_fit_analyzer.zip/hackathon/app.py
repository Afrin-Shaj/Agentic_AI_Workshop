import streamlit as st
import os
import logging
from PyPDF2 import PdfReader
import re
import json
from typing import Dict, List, Tuple
import pandas as pd
from dotenv import load_dotenv
import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse, urljoin, urlencode, parse_qs, urlparse as url_parse
import time
import uuid
import matplotlib.pyplot as plt
from io import BytesIO
from docx import Document
from docx.shared import Inches
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.keys import Keys

try:
    from langchain_google_genai import ChatGoogleGenerativeAI
except ImportError:
    import google.generativeai as genai
    ChatGoogleGenerativeAI = None

from langchain.prompts import PromptTemplate
from langchain.schema import HumanMessage
from langchain.chains import LLMChain
from typing import Optional, List as TypingList
import google.generativeai as genai

# Configure logging
logging.basicConfig(level=logging.INFO, filename='culture_fit_analyzer.log', 
                   format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Load environment variables
load_dotenv()
api_key = os.getenv("GOOGLE_API_KEY")

if not api_key:
    st.error("GOOGLE_API_KEY not found. Please set it in your .env file.")
    st.stop()

# Initialize LLM
if ChatGoogleGenerativeAI:
    try:
        llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=api_key,
            temperature=0.3,
            max_output_tokens=4096
        )
        USE_LANGCHAIN = True
        logger.info("Initialized LangChain LLM successfully")
    except Exception as e:
        logger.warning(f"LangChain initialization failed: {e}")
        genai.configure(api_key=api_key)
        llm = genai.GenerativeModel("gemini-1.5-flash")
        USE_LANGCHAIN = False
else:
    genai.configure(api_key=api_key)
    llm = genai.GenerativeModel("gemini-1.5-flash")
    USE_LANGCHAIN = False
    logger.info("Initialized direct Google AI LLM")

def scrape_website_content(url: str) -> str:
    """Scrape content from a website URL with LinkedIn authentication"""
    try:
        parsed_url = url_parse(url)
        clean_url = f"{parsed_url.scheme}://{parsed_url.netloc}{parsed_url.path}"
        
        if 'linkedin.com' in parsed_url.netloc:
            # Hardcoded LinkedIn credentials
            LINKEDIN_EMAIL = "afrin.s.ihub@snsgroups.com"
            LINKEDIN_PASSWORD = "Afrin@password123"
            
            # Configure Selenium
            chrome_options = Options()
            # Comment out headless for testing; re-enable for production
            # chrome_options.add_argument("--headless")
            chrome_options.add_argument("--no-sandbox")
            chrome_options.add_argument("--disable-dev-shm-usage")
            chrome_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36")
            
            driver = webdriver.Chrome(options=chrome_options)
            try:
                # Navigate to LinkedIn login page
                driver.get("https://www.linkedin.com/login")
                WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.ID, "username"))
                )
                
                # Perform login
                driver.find_element(By.ID, "username").send_keys(LINKEDIN_EMAIL)
                driver.find_element(By.ID, "password").send_keys(LINKEDIN_PASSWORD)
                driver.find_element(By.XPATH, "//button[@type='submit']").click()
                
                # Check for MFA or login failure
                try:
                    WebDriverWait(driver, 15).until(
                        EC.url_contains("feed")  # Redirect to feed after login
                    )
                except:
                    # Check for MFA prompt
                    if driver.find_elements(By.ID, "input__phone_verification_pin") or "verify" in driver.current_url.lower():
                        logger.warning("MFA required for LinkedIn login")
                        st.error("LinkedIn login requires MFA. Please use cookies or manual input in the 'Manual Input' tab.")
                        return ""
                    else:
                        logger.warning("LinkedIn login failed")
                        st.error("LinkedIn login failed (incorrect credentials or other issue). Please verify credentials or use manual input.")
                        return ""
                
                # Navigate to profile
                driver.get(clean_url)
                WebDriverWait(driver, 15).until(
                    EC.presence_of_element_located((By.TAG_NAME, "main"))
                )
                
                # Check for login prompt or restricted access
                if "signin" in driver.current_url or driver.find_elements(By.CLASS_NAME, "authwall"):
                    logger.warning(f"Access restricted for LinkedIn URL: {clean_url}")
                    st.error("Unable to access LinkedIn profile (private or restricted). Please use manual input.")
                    return ""
                
                # Extract profile content
                soup = BeautifulSoup(driver.page_source, 'html.parser')
                profile_content = soup.find('main')
                if not profile_content:
                    logger.warning(f"No main content found for {clean_url}")
                    st.error("Failed to extract profile content. Try manual input.")
                    return ""
                
                text = profile_content.get_text(separator=' ', strip=True)
                text = re.sub(r'\s+', ' ', text).strip()
                if len(text) > 6000:
                    text = text[:6000] + "..."
                
                logger.info(f"Successfully scraped LinkedIn profile: {clean_url}")
                return text
            
            except Exception as e:
                logger.error(f"Selenium error scraping LinkedIn {clean_url}: {str(e)}")
                st.error(f"Error scraping LinkedIn profile: {str(e)}. Try manual input in the 'Manual Input' tab.")
                return ""
            finally:
                driver.quit()
        
        else:
            # Use requests for non-LinkedIn URLs
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/117.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5'
            }
            response = requests.get(clean_url, headers=headers, timeout=10, allow_redirects=True)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            for script in soup(["script", "style", "nav", "footer"]):
                script.extract()
            
            text = soup.get_text(separator=' ', strip=True)
            text = re.sub(r'\s+', ' ', text).strip()
            
            if any(keyword in text.lower() for keyword in ['sign in', 'join now', 'password', 'email', 'agree & join']):
                logger.warning(f"Login page content detected for {clean_url}")
                st.error(f"Scraped content appears to be a login page. Please use manual input.")
                return ""
            
            if len(text) > 6000:
                text = text[:6000] + "..."
                
            logger.info(f"Successfully scraped content from {clean_url}")
            return text
            
    except requests.exceptions.RequestException as e:
        logger.error(f"Request error scraping {clean_url}: {str(e)}")
        st.error(f"Error scraping {clean_url}: {str(e)}")
        return ""
    except Exception as e:
        logger.error(f"Unexpected error scraping {clean_url}: {str(e)}")
        st.error(f"Unexpected error scraping {clean_url}: {str(e)}")
        return ""

def extract_text_from_pdf(uploaded_file) -> str:
    """Extract text from PDF with improved error handling"""
    try:
        reader = PdfReader(uploaded_file)
        text = ""
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
        logger.info(f"Successfully extracted text from PDF")
        return clean_text(text)
    except Exception as e:
        logger.error(f"Error reading PDF: {str(e)}")
        st.error(f"Error reading PDF: {str(e)}")
        return ""

def clean_text(text: str) -> str:
    """Clean and normalize text"""
    if not text:
        return ""
    text = re.sub(r'\s+', ' ', text.strip())
    text = re.sub(r'[^\w\s\-.,;:!?()]', '', text)
    return text

def call_llm_with_prompt(prompt_text: str) -> str:
    """Call LLM with retry logic"""
    max_retries = 3
    for attempt in range(max_retries):
        try:
            if USE_LANGCHAIN:
                response = llm.invoke([HumanMessage(content=prompt_text)])
                return response.content
            else:
                response = llm.generate_content(prompt_text)
                return response.text
        except Exception as e:
            logger.warning(f"LLM call attempt {attempt+1} failed: {str(e)}")
            if attempt == max_retries - 1:
                logger.error(f"LLM call failed after {max_retries} attempts: {str(e)}")
                st.error(f"Error calling LLM: {str(e)}")
                return ""
            time.sleep(2 ** attempt)  # Exponential backoff

def parse_json_response(response_text: str) -> Dict:
    """Parse JSON response with fallback"""
    try:
        cleaned_text = response_text.strip()
        if cleaned_text.startswith('```json'):
            cleaned_text = cleaned_text.replace('```json', '').replace('```', '').strip()
        elif cleaned_text.startswith('```'):
            cleaned_text = cleaned_text.replace('```', '').strip()
        
        return json.loads(cleaned_text)
    except json.JSONDecodeError as e:
        logger.error(f"JSON parsing error: {str(e)}")
        st.error(f"Error parsing JSON response: {str(e)}")
        return {"error": f"JSON parsing failed: {str(e)}"}

def analyze_candidate_behavior(candidate_data: Dict[str, str]) -> Dict:
    """Agent 1: Enhanced Candidate Behavior Analyzer"""
    combined_text = "\n".join(
        f"{key.capitalize()}: {value}" for key, value in candidate_data.items() if value
    )
    
    if not combined_text.strip():
        return {"error": "No valid candidate data provided"}
    
    prompt_text = f"""
    You are an expert behavioral analyst. Analyze the candidate's information to extract detailed personality cues, communication patterns, and behavioral traits. Use evidence-based reasoning and focus on subtle indicators like tone, word choice, and context.

    Candidate Information:
    {combined_text}

    Provide a structured JSON output:
    {{
        "personality_traits": [
            {{"trait": "openness", "evidence": "example from text", "confidence": 0.9}},
            {{"trait": "conscientiousness", "evidence": "example", "confidence": 0.8}}
        ],
        "soft_skills": [
            {{"skill": "empathy", "evidence": "example", "level": "high/medium/low", "context": "teamwork"}},
            {{"skill": "problem-solving", "evidence": "example", "level": "high/medium/low", "context": "projects"}}
        ],
        "communication_patterns": [
            {{"pattern": "assertive", "evidence": "example", "frequency": "often/sometimes/rarely"}},
            {{"pattern": "diplomatic", "evidence": "example", "frequency": "often/sometimes/rarely"}}
        ],
        "work_style": [
            {{"style": "collaborative", "evidence": "example", "preference": "strong/moderate/weak"}},
            {{"style": "independent", "evidence": "example", "preference": "strong/moderate/weak"}}
        ],
        "core_values": [
            {{"value": "innovation", "evidence": "example", "importance": "high/medium/low"}}
        ],
        "emotional_intelligence": "high/medium/low",
        "summary": "Detailed behavioral profile summary"
    }}

    Ensure at least 4-6 items per list where possible. If data is missing, note "insufficient evidence" and lower confidence scores.
    """
    
    response_text = call_llm_with_prompt(prompt_text)
    if response_text:
        logger.info("Candidate behavior analysis completed")
        return parse_json_response(response_text)
    else:
        logger.error("Candidate behavior analysis failed")
        return {"error": "Analysis failed"}

def extract_company_culture(company_data: Dict[str, str]) -> Dict:
    """Agent 2: Enhanced Company Culture Retriever with RAG"""
    combined_text = "\n".join(
        f"{key.capitalize()}: {value}" for key, value in company_data.items() if value
    )
    
    if not combined_text.strip():
        return {"error": "No valid company data provided"}
    
    prompt_text = f"""
    You are an expert in organizational culture analysis using Retrieval-Augmented Generation (RAG). Extract detailed cultural values, behavioral expectations, and environmental traits from the provided company information. Cross-reference data sources to validate insights.

    Company Information:
    {combined_text}

    Provide a structured JSON output:
    {{
        "core_values": [
            {{"value": "transparency", "evidence": "example from text", "importance": "critical/high/medium", "source": "handbook"}},
            {{"value": "diversity", "evidence": "example", "importance": "critical/high/medium", "source": "reviews"}}
        ],
        "work_environment": [
            {{"aspect": "agility", "evidence": "example", "expectation": "high adaptability", "source": "job_desc"}},
            {{"aspect": "collaboration", "evidence": "example", "expectation": "team-oriented", "source": "about_us"}}
        ],
        "behavioral_expectations": [
            {{"behavior": "proactivity", "evidence": "example", "required_level": "high/medium/low", "source": "handbook"}},
            {{"behavior": "resilience", "evidence": "example", "required_level": "high/medium/low", "source": "reviews"}}
        ],
        "communication_norms": [
            {{"norm": "open feedback", "evidence": "example", "enforcement": "strict/moderate/relaxed"}}
        ],
        "preferred_work_mode": "remote/hybrid/office",
        "cultural_red_flags": [
            {{"issue": "high turnover", "evidence": "example", "severity": "high/medium/low"}}
        ],
        "summary": "Comprehensive culture summary with cross-referenced insights"
    }}

    Ensure at least 4-6 items per list where possible. Validate insights across sources and note conflicting evidence.
    """
    
    response_text = call_llm_with_prompt(prompt_text)
    if response_text:
        logger.info("Company culture extraction completed")
        return parse_json_response(response_text)
    else:
        logger.error("Company culture extraction failed")
        return {"error": "Analysis failed"}

def map_compatibility(candidate_analysis: Dict, company_analysis: Dict) -> Dict:
    """Agent 3: Enhanced Compatibility Mapping"""
    if 'error' in candidate_analysis or 'error' in company_analysis:
        return {"error": "Invalid input data"}
    
    prompt_text = f"""
    You are an expert in aligning candidate profiles with company cultures. Compare the candidate's behavioral traits, soft skills, and work style with the company's cultural expectations and environment. Focus on nuanced compatibility factors.

    Candidate Profile:
    {json.dumps(candidate_analysis, indent=2)}

    Company Culture:
    {json.dumps(company_analysis, indent=2)}

    Provide a structured JSON output:
    {{
        "compatibility_scores": {{
            "values_alignment": {{"score": 90, "explanation": "Shared emphasis on innovation"}},
            "work_style_match": {{"score": 85, "explanation": "Prefers collaborative work, aligns with team-oriented culture"}},
            "communication_compatibility": {{"score": 80, "explanation": "Diplomatic style fits open feedback norms"}},
            "behavioral_fit": {{"score": 88, "explanation": "Proactivity matches high expectations"}},
            "emotional_intelligence_fit": {{"score": 75, "explanation": "Moderate EI in high-pressure environment"}}
        }},
        "alignment_strengths": [
            {{"area": "teamwork", "evidence": "example", "impact": "positive"}}
        ],
        "potential_mismatches": [
            {{"area": "pace", "risk": "medium", "explanation": "Prefers structured pace vs fast-moving culture"}}
        ],
        "adaptation_requirements": [
            {{"area": "agility", "adjustment": "Needs to adapt to rapid changes", "difficulty": "moderate"}}
        ],
        "summary": "Detailed compatibility analysis"
    }}

    Scores range from 0-100. Provide specific evidence and actionable insights.
    """
    
    response_text = call_llm_with_prompt(prompt_text)
    if response_text:
        logger.info("Compatibility mapping completed")
        return parse_json_response(response_text)
    else:
        logger.error("Compatibility mapping failed")
        return {"error": "Mapping failed"}

def score_culture_fit(compatibility_analysis: Dict) -> Dict:
    """Agent 4: Enhanced Culture Fit Scoring"""
    if 'error' in compatibility_analysis:
        return {"error": "Invalid input data"}
    
    prompt_text = f"""
    You are an expert in culture fit assessment. Use the compatibility analysis to generate a nuanced culture fit score, identify onboarding challenges, and provide actionable recommendations.

    Compatibility Analysis:
    {json.dumps(compatibility_analysis, indent=2)}

    Provide a structured JSON output:
    {{
        "overall_fit_score": 87,
        "detailed_scores": {{
            "values": {{"score": 90, "weight": 0.3, "explanation": "Strong alignment on core values"}},
            "work_style": {{"score": 85, "weight": 0.25, "explanation": "Good fit with minor adjustments"}},
            "communication": {{"score": 80, "weight": 0.2, "explanation": "Compatible with norms"}},
            "behavior": {{"score": 88, "weight": 0.15, "explanation": "Meets expectations"}},
            "emotional_intelligence": {{"score": 75, "weight": 0.1, "explanation": "Room for growth"}}
        }},
        "strengths": [
            {{"area": "collaboration", "explanation": "Strong team-oriented approach"}}
        ],
        "challenges": [
            {{"area": "pace", "risk_level": "medium", "explanation": "May struggle with rapid changes"}}
        ],
        "recommendations": [
            {{"action": "Discuss pace expectations", "context": "interview"}}
        ],
        "interview_questions": [
            {{"question": "How do you handle rapid priority shifts?", "purpose": "Assess agility"}}
        ],
        "onboarding_plan": [
            {{"step": "Assign mentor for pace guidance", "timeline": "First 30 days"}}
        ],
        "summary": "Comprehensive fit assessment with weighted scoring"
    }}

    Calculate overall_fit_score as a weighted average of detailed_scores. Provide specific, actionable recommendations.
    """
    
    response_text = call_llm_with_prompt(prompt_text)
    if response_text:
        logger.info("Culture fit scoring completed")
        return parse_json_response(response_text)
    else:
        logger.error("Culture fit scoring failed")
        return {"error": "Scoring failed"}

def generate_bar_chart(scores_df):
    """Generate bar chart as an image using matplotlib"""
    plt.figure(figsize=(8, 4))
    plt.bar(scores_df['Dimension'], scores_df['Score'], color='skyblue')
    plt.xlabel('Dimension')
    plt.ylabel('Score')
    plt.title('Score Breakdown')
    plt.xticks(rotation=45)
    plt.tight_layout()
    
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    buffer.seek(0)
    plt.close()
    return buffer

def generate_docx_report(candidate_analysis, company_analysis, compatibility_analysis, fit_analysis):
    """Generate DOCX report using python-docx"""
    doc = Document()
    doc.add_heading('Culture Fit Analysis Report', 0)
    doc.add_paragraph(f'Date: June 17, 2025')

    if 'overall_fit_score' in fit_analysis:
        score = fit_analysis['overall_fit_score']
        doc.add_heading('Overall Culture Fit Score', level=1)
        doc.add_paragraph(f'Score: {score}/100')
        if score >= 90:
            doc.add_paragraph('Excellent Cultural Fit', style='Intense Quote')
        elif score >= 80:
            doc.add_paragraph('Good Cultural Fit', style='Intense Quote')
        elif score >= 70:
            doc.add_paragraph('Moderate Cultural Fit', style='Intense Quote')
        else:
            doc.add_paragraph('Poor Cultural Fit', style='Intense Quote')

    doc.add_heading('Candidate Profile', level=1)
    if 'summary' in candidate_analysis:
        doc.add_paragraph(candidate_analysis['summary'])
    if 'personality_traits' in candidate_analysis:
        doc.add_heading('Personality Traits', level=2)
        for trait in candidate_analysis['personality_traits'][:5]:
            doc.add_paragraph(f"• {trait.get('trait', 'N/A')}: Confidence {trait.get('confidence', 'N/A')}", style='List Bullet')

    doc.add_heading('Company Culture', level=1)
    if 'summary' in company_analysis:
        doc.add_paragraph(company_analysis['summary'])
    if 'core_values' in company_analysis:
        doc.add_heading('Core Values')
        for value in company_analysis['core_values'][:5]:
            doc.add_paragraph(f"• {value.get('value', 'N/A')}: {value.get('importance', 'N/A')}")
        
    if 'detailed_scores' in fit_analysis:
        doc.add_heading('Score Breakdown', level=1)
        scores_df = pd.DataFrame(
            [(k, v['score'], v['weight']) for k, v in fit_analysis['detailed_scores'].items()],
            columns=['Dimension', 'Score', 'Weight']
        )
        chart_buffer = generate_bar_chart(scores_df)
        doc.add_picture(chart_buffer, width=Inches(5.0))

    doc.add_heading('Strengths', level=1)
    if 'strengths' in fit_analysis:
        for strength in fit_analysis['strengths']:
            p = doc.add_paragraph()
            p.add_run(f"{strength.get('area', 'N/A')}: ").bold = True
            p.add_run(strength.get('explanation', 'N/A'))

    doc.add_heading('Challenges', level=1)
    if 'challenges' in fit_analysis:
        for challenge in fit_analysis['challenges']:
            p = doc.add_paragraph()
            p.add_run(f"{challenge.get('area', 'N/A')}: ").bold = True
            p.add_run(challenge.get('explanation', 'N/A'))

    doc.add_heading('Recommendations', level=1)
    if 'recommendations' in fit_analysis:
        for i, rec in enumerate(fit_analysis['recommendations'], 1):
            doc.add_paragraph(f"{i}. {rec['action']} ({rec['context']})")

    doc.add_heading('Interview Questions', level=1)
    if 'interview_questions' in fit_analysis:
        for i, q in enumerate(fit_analysis['interview_questions'], 1):
            doc.add_paragraph(f"{i}. {q['question']} ({q['purpose']})")

    doc.add_heading('Onboarding Plan', level=1)
    if 'onboarding_plan' in fit_analysis:
        for i, step in enumerate(fit_analysis['onboarding_plan'], 1):
            doc.add_paragraph(f"{i}. {step['step']} ({step['timeline']})")

    buffer = BytesIO()
    doc.save(buffer)
    buffer.seek(0)
    return buffer

def display_results(candidate_analysis: Dict, company_analysis: Dict, compatibility_analysis: Dict, fit_analysis: Dict):
    """Display professional results with visualizations"""
    st.header("📊 Culture Fit Analysis Results")
    
    # Download Button (DOCX only)
    docx_buffer = generate_docx_report(candidate_analysis, company_analysis, compatibility_analysis, fit_analysis)
    st.download_button(
        label="📋 Download DOCX Report",
        data=docx_buffer,
        file_name="culture_fit_report.docx",
        mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    )
    
    # Overall Score
    if 'overall_fit_score' in fit_analysis:
        score = fit_analysis['overall_fit_score']
        st.metric("Overall Culture Fit Score", f"{score}/100")
        
        if score >= 90:
            st.success("🟢 Exceptional Fit: Highly aligned with company culture")
        elif score >= 80:
            st.info("🔵 Strong Fit: Good alignment with company culture")
        elif score >= 70:
            st.warning("🟡 Moderate Fit: Partial alignment with some gaps")
        else:
            st.error("🔴 Limited Fit: Significant cultural misalignment")
    
    # Detailed Breakdown
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("👤 Candidate Profile")
        if 'summary' in candidate_analysis:
            st.write(candidate_analysis['summary'])
        if 'personality_traits' in candidate_analysis:
            st.write("**Key Traits:**")
            for trait in candidate_analysis['personality_traits'][:5]:
                st.write(f"• {trait.get('trait', 'N/A')}: Confidence {trait.get('confidence', 'N/A')}")
    
    with col2:
        st.subheader("🏢 Company Culture")
        if 'summary' in company_analysis:
            st.write(company_analysis['summary'])
        if 'core_values' in company_analysis:
            st.write("**Core Values:**")
            for value in company_analysis['core_values'][:5]:
                st.write(f"• {value.get('value', 'N/A')}: {value.get('importance', 'N/A')} ({value.get('source', 'N/A')})")
    
    # Score Breakdown
    if 'detailed_scores' in fit_analysis:
        st.subheader("📈 Score Breakdown")
        scores_df = pd.DataFrame(
            [(k, v['score']) for k, v in fit_analysis['detailed_scores'].items()],
            columns=['Dimension', 'Score']
        )
        st.bar_chart(scores_df.set_index('Dimension')['Score'])
    
    # Strengths and Challenges
    col3, col4 = st.columns(2)
    
    with col3:
        if 'strengths' in fit_analysis:
            st.subheader("✅ Strengths")
            for strength in fit_analysis['strengths']:
                st.success(f"**{strength.get('area', 'N/A')}**: {strength.get('explanation', 'N/A')}")
    
    with col4:
        if 'challenges' in fit_analysis:
            st.subheader("⚠️ Challenges")
            for challenge in fit_analysis['challenges']:
                risk_level = challenge.get('risk_level', 'medium')
                if risk_level == 'high':
                    st.error(f"**{challenge.get('area', 'N/A')}**: {challenge.get('explanation', 'N/A')}")
                elif risk_level == 'medium':
                    st.warning(f"**{challenge.get('area', 'N/A')}**: {challenge.get('explanation', 'N/A')}")
                else:
                    st.info(f"**{challenge.get('area', 'N/A')}**: {challenge.get('explanation', 'N/A')}")
    
    # Recommendations and Questions
    col5, col6 = st.columns(2)
    
    with col5:
        if 'recommendations' in fit_analysis:
            st.subheader("💡 Recommendations")
            for i, rec in enumerate(fit_analysis['recommendations'], 1):
                st.write(f"{i}. {rec['action']} ({rec['context']})")
    
    with col6:
        if 'interview_questions' in fit_analysis:
            st.subheader("🎯 Interview Questions")
            for i, q in enumerate(fit_analysis['interview_questions'], 1):
                st.write(f"{i}. {q['question']} ({q['purpose']})")
    
    # Onboarding Plan
    if 'onboarding_plan' in fit_analysis:
        st.subheader("🚀 Onboarding Plan")
        for i, step in enumerate(fit_analysis['onboarding_plan'], 1):
            st.write(f"{i}. {step['step']} ({step['timeline']})")

# Streamlit UI
st.set_page_config(page_title="Culture Fit Analyzer", layout="wide")
st.title("🧠 AI-Powered Culture Fit Analyzer")
st.markdown("Evaluate candidate alignment with company culture using advanced AI insights.")

# Sidebar
with st.sidebar:
    st.header("📋 Instructions")
    st.markdown("""
    **Quick Analysis:**
    1. Enter candidate profile URLs (e.g., LinkedIn, GitHub)
    2. Enter company URLs (e.g., About, Careers)
    3. Click 'Quick Analysis'
                
    **Manual Input:**
    1. Upload candidate files or enter text
    2. Upload company files or enter text
    3. Click 'Analyze Culture Fit'
    
    **Results:**
    - View results in the 'Results' tab after analysis
    - Download report as DOCX

    """)

# Tabs
tab1, tab2, tab3 = st.tabs(["⚡ Quick Analysis", "📄 Manual Input", "📊 Results"])

with tab1:
    st.header("⚡ Quick Analysis - URL Based")
    st.markdown("*Enter URLs to scrape and analyze content.*")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("👤 Candidate URLs")
        candidate_linkedin = st.text_input("LinkedIn Profile URL", value="https://www.linkedin.com/in/afrin-s-snsihub-412139370/")
        candidate_github = st.text_input("GitHub Profile URL", placeholder="https://github.com/username")
        candidate_portfolio = st.text_input("Portfolio/Personal Website", placeholder="https://portfolio.com")
        candidate_other = st.text_input("Other Profile URL", placeholder="Any other relevant URL")
    
    with col2:
        st.subheader("🏢 Company URLs")
        company_about = st.text_input("Company About Page", placeholder="https://company.com/about")
        company_careers = st.text_input("Careers/Jobs Page", placeholder="https://company.com/careers")
        company_glassdoor = st.text_input("Glassdoor URL", placeholder="https://glassdoor.com/company/...")
        company_other = st.text_input("Other Company URL", placeholder="Any other relevant URL")
    
    if st.button("🚀 Quick Analysis", type="primary"):
        candidate_urls = [url for url in [candidate_linkedin, candidate_github, candidate_portfolio, candidate_other] if url.strip()]
        company_urls = [url for url in [company_about, company_careers, company_glassdoor, company_other] if url.strip()]
        
        if not candidate_urls or not company_urls:
            st.error("Please provide at least one candidate URL and one company URL.")
        else:
            with st.spinner("Scraping and analyzing content..."):
                candidate_content = {}
                for i, url in enumerate(candidate_urls):
                    with st.status(f"Scraping candidate URL {i+1}/{len(candidate_urls)}...") as status:
                        content = scrape_website_content(url)
                        if content:
                            st.write(f"**Preview of scraped content:** {content[:200]}{'...' if len(content) > 200 else ''}")
                            if 'linkedin' in url.lower():
                                candidate_content['linkedin'] = content
                            elif 'github' in url.lower():
                                candidate_content['github'] = content
                            else:
                                candidate_content['bio'] = candidate_content.get('bio', '') + content
                        else:
                            st.write("No content scraped from this URL. Consider manual input.")
                        status.update(label=f"Completed scraping candidate URL {i+1}/{len(candidate_urls)}")
                        time.sleep(0.5)
                
                company_content = {}
                for i, url in enumerate(company_urls):
                    with st.status(f"Scraping company URL {i+1}/{len(company_urls)}...") as status:
                        content = scrape_website_content(url)
                        if content:
                            st.write(f"**Preview of scraped content:** {content[:200]}{'...' if len(content) > 200 else ''}")
                            if 'about' in url.lower() or 'company' in url.lower():
                                company_content['about_us'] = content
                            elif 'career' in url.lower() or 'job' in url.lower():
                                company_content['job_desc'] = content
                            elif 'glassdoor' in url.lower():
                                company_content['reviews'] = content
                            else:
                                company_content['about_us'] = company_content.get('about_us', '') + content
                        else:
                            st.write("No content scraped from this URL.")
                        status.update(label=f"Completed scraping company URL {i+1}/{len(company_urls)}")
                        time.sleep(0.5)
                
                # Combine with manual input if available
                manual_candidate_data = st.session_state.get('manual_candidate_data', {})
                manual_company_data = st.session_state.get('manual_company_data', {})
                
                if not candidate_content and not manual_candidate_data:
                    st.error("No valid candidate data from URLs. Please provide data via 'Manual Input' tab.")
                elif not company_content and not manual_company_data:
                    st.error("No valid company data from URLs. Please provide data via 'Manual Input' tab.")
                else:
                    with st.status("Analyzing candidate behavior...") as status:
                        combined_candidate_data = {**candidate_content, **manual_candidate_data}
                        combined_company_data = {**company_content, **manual_company_data}
                        
                        candidate_analysis = analyze_candidate_behavior(combined_candidate_data)
                        status.update(label="Extracting company culture...")
                        
                        if 'error' not in candidate_analysis:
                            company_analysis = extract_company_culture(combined_company_data)
                            status.update(label="Mapping compatibility...")
                            
                            if 'error' not in company_analysis:
                                compatibility_analysis = map_compatibility(candidate_analysis, company_analysis)
                                status.update(label="Scoring culture fit...")
                                
                                if 'error' not in compatibility_analysis:
                                    fit_analysis = score_culture_fit(compatibility_analysis)
                                    status.update(label="Quick analysis complete!", state="complete")
                                    
                                    st.session_state['candidate_analysis'] = candidate_analysis
                                    st.session_state['company_analysis'] = company_analysis
                                    st.session_state['compatibility_analysis'] = compatibility_analysis
                                    st.session_state['fit_analysis'] = fit_analysis
                                    
                                    st.success("Analysis complete! Check the Results tab.")
                                else:
                                    st.error("Compatibility mapping failed.")
                            else:
                                st.error("Company analysis failed.")
                        else:
                            st.error("Candidate profiling failed.")

with tab2:
    col1, col2 = st.columns(2)
    
    with col1:
        st.header("👤 Candidate Information")
        resume_file = st.file_uploader("Upload Resume/CV (PDF)", type="pdf")
        linkedin_bio = st.text_area("LinkedIn Profile / Professional Bio", height=120)
        github_content = st.text_area("GitHub README / Portfolio Description", height=100)
        personal_bio = st.text_area("Personal Statement / Cover Letter", height=100)
    
    with col2:
        st.header("🏢 Company Information")
        hr_file = st.file_uploader("Upload HR Policy / Handbook (PDF)", type="pdf")
        about_company = st.text_area("About Us / Company Description", height=120)
        employee_reviews = st.text_area("Employee Reviews / Glassdoor Summary", height=100)
        job_description = st.text_area("Job Description", height=100)
    
    if st.button("🔍 Analyze Culture Fit", type="primary"):
        with st.spinner("Running AI analysis..."):
            candidate_data = {
                'resume': extract_text_from_pdf(resume_file) if resume_file else "",
                'linkedin': linkedin_bio or "",
                'github': github_content or "",
                'bio': personal_bio or ""
            }
            
            company_data = {
                'hr_policy': extract_text_from_pdf(hr_file) if hr_file else "",
                'about_us': about_company or "",
                'reviews': employee_reviews or "",
                'job_desc': job_description or ""
            }
            
            if not any(candidate_data.values()) or not any(company_data.values()):
                st.error("Please provide at least some candidate and company information.")
            else:
                with st.status("Analyzing candidate behavior...") as status:
                    st.session_state['manual_candidate_data'] = candidate_data
                    st.session_state['manual_company_data'] = company_data
                    
                    candidate_analysis = analyze_candidate_behavior(candidate_data)
                    status.update(label="Extracting company culture...")
                    
                    if 'error' not in candidate_analysis:
                        company_analysis = extract_company_culture(company_data)
                        status.update(label="Mapping compatibility...")
                        
                        if 'error' not in company_analysis:
                            compatibility_analysis = map_compatibility(candidate_analysis, company_analysis)
                            status.update(label="Scoring culture fit...")
                            
                            if 'error' not in compatibility_analysis:
                                fit_analysis = score_culture_fit(compatibility_analysis)
                                status.update(label="Analysis complete!", state="complete")
                                
                                st.session_state['candidate_analysis'] = candidate_analysis
                                st.session_state['company_analysis'] = company_analysis
                                st.session_state['compatibility_analysis'] = compatibility_analysis
                                st.session_state['fit_analysis'] = fit_analysis
                                
                                st.success("Analysis complete! Check the Results tab.")
                            else:
                                st.error("Compatibility mapping failed.")
                        else:
                            st.error("Company analysis failed.")
                    else:
                        st.error("Candidate analysis failed.")

with tab3:
    if all(key in st.session_state for key in ['candidate_analysis', 'company_analysis', 'compatibility_analysis', 'fit_analysis']):
        display_results(
            st.session_state['candidate_analysis'],
            st.session_state['company_analysis'],
            st.session_state['compatibility_analysis'],
            st.session_state['fit_analysis']
        )
    else:
        st.info("Run 'Quick Analysis' or 'Manual Analysis' first to see results. If LinkedIn scraping fails, use the 'Manual Input' tab.")

# Footer
st.markdown("---")
st.markdown("*This tool uses AI to provide culture fit insights. Results should complement human judgment.*")