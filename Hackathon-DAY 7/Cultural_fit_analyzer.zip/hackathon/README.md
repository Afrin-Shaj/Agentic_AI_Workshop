Culture Fit Analyzer
A Streamlit-based tool that uses AI to evaluate candidate alignment with company culture by analyzing URLs or manually input data, generating detailed reports with compatibility scores, insights, and visualizations.
🚀 Quick Start Instructions
Option 1: Quick Analysis (Recommended)

Navigate to the "⚡ Quick Analysis" tab.
Enter URLs for candidate and company data:

SAMPLES:

Candidate URLs (e.g., LinkedIn, GitHub):
LinkedIn Profile: https://www.linkedin.com/in/afrin-s-snsihub-412139370/ (pre-filled)
GitHub Profile URL: https://github.com/torvalds (OPTIONAL)
Portfolio/Personal Website: https://brendaneich.com/ (OPTIONAL)
Other Profile URL: https://news.ycombinator.com/user?id=torvalds (OPTIONAL)
 
Company URLs (e.g., About page, Glassdoor):
Company About Page: https://about.gitlab.com/
Careers/Jobs Page: https://about.gitlab.com/jobs/
Glassdoor URL: https://www.glassdoor.com/Overview/Working-at-GitLab-EI_IE1296544.11,17.htm
Other Company URL: https://handbook.gitlab.com/handbook/values/


Click the "🚀 Quick Analysis" button.
Wait for scraping and analysis to complete (view progress in status updates).
Go to the "📊 Results" tab to view the analysis and download the DOCX report.

Note: LinkedIn scraping uses automated login with provided credentials. If it fails (e.g., due to MFA or private profiles), use Option 2.
Option 2: Manual Analysis

Go to the "📄 Manual Input" tab.
Upload PDF files (e.g., resume, HR handbook) or paste text for:
Candidate: LinkedIn bio, GitHub README, personal statement.
Company: About page, employee reviews, job description.

Click the "🔍 Analyze Culture Fit" button.
View results in the "📊 Results" tab and download the DOCX report.
