Culture Fit Analyzer - README
🚀 Quick Start Instructions
Option 1: Quick Analysis (Recommended)

Navigate to the "⚡ Quick Analysis" tab
Enter the following sample URLs to test the system:

👤 Candidate URLs:

LinkedIn Profile URL: https://www.linkedin.com/in/swetha-guru-36a98b1bb?utm_source=share&utm_campaign=share_via&utm_content=profile&utm_medium=android_app
GitHub README URL: https://raw.githubusercontent.com/torvalds/linux/master/README
Portfolio/Personal Website: (optional)
Other Profile URL: (optional)

🏢 Company URLs:

Company About Page: https://about.gitlab.com/blog/2022/05/03/how-gitlabs-customer-and-partner-focus-fuels-our-culture/
Careers/Jobs Page: https://about.gitlab.com/blog/2020/07/07/how-to-optimize-gitlabs-culture-with-proper-values/
Glassdoor URL: https://www.glassdoor.com/Reviews/iHerb-company-culture-Reviews-EI_IE409565.0,5_KH6,21.htm
Other Company URL: (optional)
Click "🚀 Quick Analysis" button
Wait for scraping and analysis to complete
View results in the "📊 Results" tab

Option 2: Manual Analysis

Go to "📄 Manual Input" tab
Upload PDF files or paste text content for candidate and company information
Navigate to "🔍 Analysis" tab
Click "🔍 Analyze Culture Fit" button
View results in "📊 Results" tab

📋 Prerequisites
Required Dependencies:
bashpip install streamlit PyPDF2 pandas python-dotenv requests beautifulsoup4 langchain-google-genai google-generativeai
Environment Setup:

Create a .env file in your project directory
Add your Google API key: GOOGLE_API_KEY=your_api_key_here
Get your API key from Google AI Studio

🎯 Key Features

Quick Analysis: URL-based automatic content scraping and analysis
Manual Analysis: Upload files and input text manually
AI-Powered: Uses Google Gemini for behavioral and cultural analysis
Comprehensive Scoring: Multi-dimensional culture fit scoring
Actionable Insights: Interview focus areas and onboarding suggestions
Visual Results: Charts and color-coded fit assessments

⚠️ Important Notes

For Manual Analysis: You must go to the "🔍 Analysis" tab and click the analyze button after entering data in Manual Input
Web Scraping: Some websites may block automated requests - try different URLs if scraping fails
Rate Limiting: Quick analysis includes delays between URL requests to be respectful to websites
Content Quality: Better quality URLs (detailed profiles, comprehensive company pages) yield better analysis results

🔧 Troubleshooting

If scraping fails, try copying content manually into the Manual Input tab
Ensure your Google API key is valid and has sufficient quota
Check that all required dependencies are installed
Some LinkedIn profiles may require login - try public portfolio URLs instead