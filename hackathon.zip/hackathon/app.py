import streamlit as st
import os
from PyPDF2 import PdfReader
import re
import json
from typing import Dict, List, Tuple
import pandas as pd
from dotenv import load_dotenv
import requests
from bs4 import BeautifulSoup
from urllib.parse import urlparse
import time

try:
    from langchain_google_genai import ChatGoogleGenerativeAI
except ImportError:
    # Fallback to direct Google Generative AI if LangChain version conflicts
    import google.generativeai as genai
    ChatGoogleGenerativeAI = None

from langchain.prompts import PromptTemplate
from langchain.schema import HumanMessage
from langchain.chains import LLMChain
from typing import Optional, List as TypingList
import google.generativeai as genai

# Use built-in json for parsing instead of PydanticOutputParser to avoid conflicts
import json

# Load environment variables from .env file
load_dotenv()

# Get the API key
api_key = os.getenv("GOOGLE_API_KEY")

if not api_key:
    st.error("GOOGLE_API_KEY not found. Please set it in your .env file.")
    st.stop()

# Initialize LLM - handle both LangChain and direct approaches
if ChatGoogleGenerativeAI:
    try:
        llm = ChatGoogleGenerativeAI(
            model="gemini-1.5-flash",
            google_api_key=api_key,
            temperature=0.3,
            max_output_tokens=4096
        )
        USE_LANGCHAIN = True
    except Exception as e:
        st.warning(f"LangChain initialization failed: {e}. Falling back to direct Google AI.")
        genai.configure(api_key=api_key)
        llm = genai.GenerativeModel("gemini-1.5-flash")
        USE_LANGCHAIN = False
else:
    genai.configure(api_key=api_key)
    llm = genai.GenerativeModel("gemini-1.5-flash")
    USE_LANGCHAIN = False

def scrape_website_content(url: str) -> str:
    """Scrape content from a website URL with error handling"""
    try:
        # Add headers to avoid being blocked
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        response = requests.get(url, headers=headers, timeout=10)
        response.raise_for_status()
        
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Remove script and style elements
        for script in soup(["script", "style"]):
            script.extract()
        
        # Get text content
        text = soup.get_text()
        
        # Clean up text
        lines = (line.strip() for line in text.splitlines())
        chunks = (phrase.strip() for line in lines for phrase in line.split("  "))
        text = ' '.join(chunk for chunk in chunks if chunk)
        
        # Limit text length to avoid token limits
        if len(text) > 5000:
            text = text[:5000] + "..."
            
        return text
        
    except requests.exceptions.RequestException as e:
        st.error(f"Error scraping {url}: {str(e)}")
        return ""
    except Exception as e:
        st.error(f"Unexpected error scraping {url}: {str(e)}")
        return ""

def extract_text_from_pdf(uploaded_file) -> str:
    """Extract text from uploaded PDF file with error handling"""
    try:
        reader = PdfReader(uploaded_file)
        text = ""
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
        return text
    except Exception as e:
        st.error(f"Error reading PDF: {str(e)}")
        return ""

def clean_text(text: str) -> str:
    """Clean and normalize text"""
    if not text:
        return ""
    # Remove extra whitespace and normalize
    text = re.sub(r'\s+', ' ', text.strip())
    # Remove special characters that might cause issues
    text = re.sub(r'[^\w\s\-.,;:!?()]', '', text)
    return text

def call_llm_with_prompt(prompt_text: str) -> str:
    """Universal function to call LLM regardless of implementation"""
    try:
        if USE_LANGCHAIN:
            # Using LangChain approach
            response = llm.invoke([HumanMessage(content=prompt_text)])
            return response.content
        else:
            # Using direct Google AI approach
            response = llm.generate_content(prompt_text)
            return response.text
    except Exception as e:
        st.error(f"Error calling LLM: {str(e)}")
        return ""

def parse_json_response(response_text: str) -> Dict:
    """Parse JSON response with error handling"""
    try:
        # Clean the response text
        cleaned_text = response_text.strip()
        if cleaned_text.startswith('```json'):
            cleaned_text = cleaned_text.replace('```json', '').replace('```', '').strip()
        elif cleaned_text.startswith('```'):
            cleaned_text = cleaned_text.replace('```', '').strip()
        
        return json.loads(cleaned_text)
    except json.JSONDecodeError as e:
        st.error(f"Error parsing JSON response: {str(e)}")
        return {"error": "JSON parsing failed"}

def analyze_candidate_behavior(candidate_data: Dict[str, str]) -> Dict:
    """Agent 1: Extract behavioral traits and values from candidate data"""
    
    combined_text = f"""
    Resume/CV: {candidate_data.get('resume', '')}
    
    LinkedIn/Professional Bio: {candidate_data.get('linkedin', '')}
    
    GitHub/Portfolio: {candidate_data.get('github', '')}
    
    Personal Statement: {candidate_data.get('bio', '')}
    """
    
    prompt_text = f"""
    Analyze the following candidate information and extract behavioral traits, soft skills, and core values.
    
    Candidate Information:
    {combined_text}
    
    Please provide a structured analysis in the following JSON format:
    {{
        "behavioral_traits": [
            {{"trait": "collaboration", "evidence": "specific example from text", "strength": "high/medium/low"}},
            {{"trait": "adaptability", "evidence": "specific example", "strength": "high/medium/low"}}
        ],
        "soft_skills": [
            {{"skill": "communication", "evidence": "example", "level": "high/medium/low"}},
            {{"skill": "leadership", "evidence": "example", "level": "high/medium/low"}}
        ],
        "work_style_preferences": [
            {{"preference": "remote work", "evidence": "example", "importance": "high/medium/low"}},
            {{"preference": "structured environment", "evidence": "example", "importance": "high/medium/low"}}
        ],
        "core_values": ["innovation", "work-life balance", "continuous learning"],
        "communication_style": "formal/informal/mixed",
        "risk_tolerance": "high/medium/low",
        "summary": "Brief summary of candidate's behavioral profile"
    }}
    
    Focus on evidence-based analysis. If information is missing, indicate "insufficient data".
    Provide at least 3-5 items for each list where possible.
    """
    
    response_text = call_llm_with_prompt(prompt_text)
    if response_text:
        return parse_json_response(response_text)
    else:
        return {"error": "Analysis failed"}

def extract_company_culture(company_data: Dict[str, str]) -> Dict:
    """Agent 2: Extract company cultural values and expectations"""
    
    combined_text = f"""
    HR Policy/Handbook: {company_data.get('hr_policy', '')}
    
    About Us/Company Description: {company_data.get('about_us', '')}
    
    Employee Reviews/Glassdoor: {company_data.get('reviews', '')}
    
    Job Description: {company_data.get('job_desc', '')}
    """
    
    prompt_text = f"""
    Analyze the following company information and extract cultural values, work environment characteristics, and behavioral expectations.
    
    Company Information:
    {combined_text}
    
    Please provide a structured analysis in the following JSON format:
    {{
        "core_values": [
            {{"value": "customer-first", "description": "specific description from text", "importance": "critical/high/medium"}},
            {{"value": "innovation", "description": "description", "importance": "critical/high/medium"}}
        ],
        "work_environment": [
            {{"aspect": "pace", "description": "fast-paced startup environment", "expectation": "high adaptability"}},
            {{"aspect": "hierarchy", "description": "flat organizational structure", "expectation": "self-direction"}}
        ],
        "behavioral_expectations": [
            {{"behavior": "collaboration", "description": "cross-functional teamwork", "required_level": "high/medium/low"}},
            {{"behavior": "ownership", "description": "taking initiative", "required_level": "high/medium/low"}}
        ],
        "communication_style": "formal/informal/mixed",
        "preferred_work_style": "remote/hybrid/office",
        "risk_tolerance": "high/medium/low",
        "red_flags": ["micromanagement", "long hours"],
        "summary": "Brief summary of company culture"
    }}
    
    Focus on concrete cultural indicators and behavioral expectations.
    """
    
    response_text = call_llm_with_prompt(prompt_text)
    if response_text:
        return parse_json_response(response_text)
    else:
        return {"error": "Analysis failed"}

def calculate_culture_fit(candidate_analysis: Dict, company_analysis: Dict) -> Dict:
    """Agent 3: Compare candidate traits with company culture and generate fit score"""
    
    prompt_text = f"""
    Compare the candidate's behavioral profile with the company's cultural expectations and calculate a culture fit score.
    
    CANDIDATE PROFILE:
    {json.dumps(candidate_analysis, indent=2)}
    
    COMPANY CULTURE:
    {json.dumps(company_analysis, indent=2)}
    
    Please provide a comprehensive culture fit analysis in the following JSON format:
    {{
        "overall_fit_score": 85,
        "dimension_scores": {{
            "values_alignment": 90,
            "work_style_compatibility": 80,
            "communication_style_match": 85,
            "behavioral_expectations": 88,
            "risk_tolerance_alignment": 75
        }},
        "strengths": [
            {{"area": "collaboration", "explanation": "Candidate's team-oriented approach aligns with company's collaborative culture"}},
            {{"area": "innovation", "explanation": "Both value continuous learning and creative problem-solving"}}
        ],
        "potential_mismatches": [
            {{"area": "work pace", "risk_level": "medium", "explanation": "Candidate prefers structured planning vs company's fast-paced environment"}},
            {{"area": "autonomy", "risk_level": "low", "explanation": "Minor preference differences in decision-making style"}}
        ],
        "recommendations": [
            "Discuss expectations around work pace and deadlines during interview",
            "Highlight opportunities for structured project management",
            "Emphasize company's commitment to work-life balance"
        ],
        "interview_focus_areas": [
            "Adaptability to changing priorities",
            "Comfort with ambiguous situations",
            "Collaboration in remote/hybrid settings"
        ],
        "onboarding_suggestions": [
            "Pair with mentor who values structured approach",
            "Gradual introduction to fast-paced projects",
            "Clear communication of expectations and feedback cycles"
        ],
        "summary": "Detailed explanation of the overall fit assessment"
    }}
    
    Score from 0-100 where:
    - 90-100: Excellent fit
    - 80-89: Good fit with minor adjustments needed
    - 70-79: Moderate fit, some areas of concern
    - 60-69: Poor fit, significant mismatches
    - Below 60: Strong misalignment
    
    Provide specific, actionable recommendations and focus areas.
    """
    
    response_text = call_llm_with_prompt(prompt_text)
    if response_text:
        return parse_json_response(response_text)
    else:
        return {"error": "Comparison failed"}

def display_results(candidate_analysis: Dict, company_analysis: Dict, fit_analysis: Dict):
    """Display comprehensive results with visualizations"""
    
    # Overall Score
    if 'overall_fit_score' in fit_analysis:
        score = fit_analysis['overall_fit_score']
        st.metric("Overall Culture Fit Score", f"{score}/100")
        
        # Color coding
        if score >= 90:
            st.success("🟢 Excellent Cultural Fit")
        elif score >= 80:
            st.info("🔵 Good Cultural Fit")
        elif score >= 70:
            st.warning("🟡 Moderate Cultural Fit")
        else:
            st.error("🔴 Poor Cultural Fit")
    
    # Detailed breakdown
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("👤 Candidate Profile")
        if 'summary' in candidate_analysis:
            st.write(candidate_analysis['summary'])
        
        if 'behavioral_traits' in candidate_analysis:
            st.write("**Key Behavioral Traits:**")
            for trait in candidate_analysis['behavioral_traits'][:5]:  # Show top 5
                st.write(f"• {trait.get('trait', 'N/A')}: {trait.get('strength', 'N/A')}")
    
    with col2:
        st.subheader("🏢 Company Culture")
        if 'summary' in company_analysis:
            st.write(company_analysis['summary'])
        
        if 'core_values' in company_analysis:
            st.write("**Core Values:**")
            for value in company_analysis['core_values'][:5]:  # Show top 5
                st.write(f"• {value.get('value', 'N/A')}: {value.get('importance', 'N/A')}")
    
    # Fit Analysis
    if 'dimension_scores' in fit_analysis:
        st.subheader("📊 Detailed Fit Analysis")
        dimension_scores = fit_analysis['dimension_scores']
        scores_df = pd.DataFrame(list(dimension_scores.items()), 
                               columns=['Dimension', 'Score'])
        st.bar_chart(scores_df.set_index('Dimension'))
    
    # Strengths and Concerns
    col3, col4 = st.columns(2)
    
    with col3:
        if 'strengths' in fit_analysis:
            st.subheader("✅ Alignment Strengths")
            for strength in fit_analysis['strengths']:
                st.success(f"**{strength.get('area', 'N/A')}**: {strength.get('explanation', 'N/A')}")
    
    with col4:
        if 'potential_mismatches' in fit_analysis:
            st.subheader("⚠️ Potential Concerns")
            for mismatch in fit_analysis['potential_mismatches']:
                risk_level = mismatch.get('risk_level', 'medium')
                if risk_level == 'high':
                    st.error(f"**{mismatch.get('area', 'N/A')}**: {mismatch.get('explanation', 'N/A')}")
                elif risk_level == 'medium':
                    st.warning(f"**{mismatch.get('area', 'N/A')}**: {mismatch.get('explanation', 'N/A')}")
                else:
                    st.info(f"**{mismatch.get('area', 'N/A')}**: {mismatch.get('explanation', 'N/A')}")
    
    # Recommendations
    if 'recommendations' in fit_analysis:
        st.subheader("💡 Recommendations")
        for i, rec in enumerate(fit_analysis['recommendations'], 1):
            st.write(f"{i}. {rec}")
    
    # Interview Focus Areas
    if 'interview_focus_areas' in fit_analysis:
        st.subheader("🎯 Interview Focus Areas")
        for i, area in enumerate(fit_analysis['interview_focus_areas'], 1):
            st.write(f"{i}. {area}")
    
    # Onboarding Suggestions
    if 'onboarding_suggestions' in fit_analysis:
        st.subheader("🚀 Onboarding Suggestions")
        for i, suggestion in enumerate(fit_analysis['onboarding_suggestions'], 1):
            st.write(f"{i}. {suggestion}")

# Streamlit UI
st.set_page_config(page_title="Culture Fit Analyzer", layout="wide")
st.title("🧠 AI-Powered Culture Fit Analyzer (LangChain)")
st.markdown("Analyze candidate-company alignment using behavioral traits, values, and cultural expectations.")

# Sidebar for instructions
with st.sidebar:
    st.header("📋 Instructions")
    st.markdown("""
    **Manual Analysis:**
    1. Upload candidate files/add content
    2. Upload company files/add content
    3. Click 'Analyze Culture Fit'
    
    **Quick Analysis:**
    1. Enter candidate profile URLs
    2. Enter company URLs
    3. Click 'Quick Analysis'
    
    **New Features:**
    - URL-based quick analysis
    - Web scraping capabilities
    - Structured output parsing
    - Better error handling
    """)

# Main interface - Updated with Quick Analysis tab
tab1, tab2, tab3 = st.tabs(["📄 Manual Input", "⚡ Quick Analysis", "📊 Results"])

with tab1:
    col1, col2 = st.columns(2)
    
    with col1:
        st.header("👤 Candidate Information")
        resume_file = st.file_uploader("Upload Resume/CV (PDF)", type="pdf", key="resume")
        linkedin_bio = st.text_area("LinkedIn Profile / Professional Bio", height=120, key="linkedin")
        github_content = st.text_area("GitHub README / Portfolio Description", height=100, key="github")
        personal_bio = st.text_area("Personal Statement / Cover Letter", height=100, key="personal")
    
    with col2:
        st.header("🏢 Company Information")
        hr_file = st.file_uploader("Upload HR Policy / Employee Handbook (PDF)", type="pdf", key="hr")
        about_company = st.text_area("About Us / Company Description", height=120, key="about")
        employee_reviews = st.text_area("Employee Reviews / Glassdoor Summary", height=100, key="reviews")
        job_description = st.text_area("Job Description", height=100, key="job_desc")
    
    # Manual Analysis Button
    if st.button("🔍 Analyze Culture Fit", type="primary", key="manual_analyze"):
        with st.spinner("Running LangChain AI analysis..."):
            
            # Prepare candidate data
            candidate_data = {
                'resume': extract_text_from_pdf(resume_file) if resume_file else "",
                'linkedin': linkedin_bio or "",
                'github': github_content or "",
                'bio': personal_bio or ""
            }
            
            # Prepare company data
            company_data = {
                'hr_policy': extract_text_from_pdf(hr_file) if hr_file else "",
                'about_us': about_company or "",
                'reviews': employee_reviews or "",
                'job_desc': job_description or ""
            }
            
            # Validate input
            if not any(candidate_data.values()) or not any(company_data.values()):
                st.error("Please provide at least some candidate and company information.")
            else:
                # Run analysis
                with st.status("Analyzing candidate behavior...") as status:
                    candidate_analysis = analyze_candidate_behavior(candidate_data)
                    status.update(label="Extracting company culture...")
                    
                if 'error' not in candidate_analysis:
                    company_analysis = extract_company_culture(company_data)
                    status.update(label="Calculating culture fit...")
                    
                    if 'error' not in company_analysis:
                        fit_analysis = calculate_culture_fit(candidate_analysis, company_analysis)
                        status.update(label="Analysis complete!", state="complete")
                        
                        # Store results in session state
                        st.session_state['candidate_analysis'] = candidate_analysis
                        st.session_state['company_analysis'] = company_analysis
                        st.session_state['fit_analysis'] = fit_analysis
                        
                        st.success("Analysis complete! Check the Results tab.")
                    else:
                        st.error("Company analysis failed. Please check your input data.")
                else:
                    st.error("Candidate analysis failed. Please check your input data.")

with tab2:
    st.header("⚡ Quick Analysis - URL Based")
    st.markdown("*Enter URLs to automatically scrape and analyze content*")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.subheader("👤 Candidate URLs")
        candidate_linkedin = st.text_input("LinkedIn Profile URL", placeholder="https://linkedin.com/in/username")
        candidate_github = st.text_input("GitHub Profile URL", placeholder="https://github.com/username")
        candidate_portfolio = st.text_input("Portfolio/Personal Website", placeholder="https://portfolio.com")
        candidate_other = st.text_input("Other Profile URL", placeholder="Any other relevant URL")
    
    with col2:
        st.subheader("🏢 Company URLs")
        company_about = st.text_input("Company About Page", placeholder="https://company.com/about")
        company_careers = st.text_input("Careers/Jobs Page", placeholder="https://company.com/careers")
        company_glassdoor = st.text_input("Glassdoor URL", placeholder="https://glassdoor.com/company/...")
        company_other = st.text_input("Other Company URL", placeholder="Any other relevant company URL")
    
    if st.button("🚀 Quick Analysis", type="primary"):
        # Collect all URLs
        candidate_urls = [url for url in [candidate_linkedin, candidate_github, candidate_portfolio, candidate_other] if url.strip()]
        company_urls = [url for url in [company_about, company_careers, company_glassdoor, company_other] if url.strip()]
        
        if not candidate_urls or not company_urls:
            st.error("Please provide at least one candidate URL and one company URL.")
        else:
            with st.spinner("Scraping and analyzing content..."):
                
                # Scrape candidate content
                candidate_content = {}
                for i, url in enumerate(candidate_urls):
                    with st.status(f"Scraping candidate URL {i+1}/{len(candidate_urls)}..."):
                        content = scrape_website_content(url)
                        if content:
                            # Categorize content based on URL
                            if 'linkedin' in url.lower():
                                candidate_content['linkedin'] = content
                            elif 'github' in url.lower():
                                candidate_content['github'] = content
                            else:
                                candidate_content['bio'] = candidate_content.get('bio', '') + content
                        time.sleep(1)  # Be respectful to websites
                
                # Scrape company content
                company_content = {}
                for i, url in enumerate(company_urls):
                    with st.status(f"Scraping company URL {i+1}/{len(company_urls)}..."):
                        content = scrape_website_content(url)
                        if content:
                            # Categorize content based on URL
                            if 'about' in url.lower() or 'company' in url.lower():
                                company_content['about_us'] = content
                            elif 'career' in url.lower() or 'job' in url.lower():
                                company_content['job_desc'] = content
                            elif 'glassdoor' in url.lower():
                                company_content['reviews'] = content
                            else:
                                company_content['about_us'] = company_content.get('about_us', '') + content
                        time.sleep(1)  # Be respectful to websites
                
                if candidate_content and company_content:
                    with st.status("Analyzing candidate behavior...") as status:
                        candidate_analysis = analyze_candidate_behavior(candidate_content)
                        status.update(label="Extracting company culture...")
                        
                    if 'error' not in candidate_analysis:
                        company_analysis = extract_company_culture(company_content)
                        status.update(label="Calculating culture fit...")
                        
                        if 'error' not in company_analysis:
                            fit_analysis = calculate_culture_fit(candidate_analysis, company_analysis)
                            status.update(label="Quick analysis complete!", state="complete")
                            
                            # Store results in session state
                            st.session_state['candidate_analysis'] = candidate_analysis
                            st.session_state['company_analysis'] = company_analysis
                            st.session_state['fit_analysis'] = fit_analysis
                            
                            st.success("Quick analysis complete! Check the Results tab.")
                        else:
                            st.error("Company analysis failed. Please check the URLs or try different ones.")
                    else:
                        st.error("Candidate analysis failed. Please check the URLs or try different ones.")
                else:
                    st.error("Failed to scrape sufficient content. Please check the URLs and try again.")

with tab3:
    if all(key in st.session_state for key in ['candidate_analysis', 'company_analysis', 'fit_analysis']):
        display_results(
            st.session_state['candidate_analysis'],
            st.session_state['company_analysis'],
            st.session_state['fit_analysis']
        )
    else:
        st.info("Run either Manual Analysis or Quick Analysis first to see results here.")

# Footer
st.markdown("---")
st.markdown("*This tool provides AI-powered insights for hiring decisions using LangChain for structured analysis. Results should be used alongside human judgment and comprehensive interviews.*")